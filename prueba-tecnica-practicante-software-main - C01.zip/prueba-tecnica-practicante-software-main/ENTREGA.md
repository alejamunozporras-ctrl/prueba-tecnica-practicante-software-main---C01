# Notas de entrega

Código de candidato: C01

Versión de Python usada: Pyton 3.13.5

## Qué funciona

- Nivel A: Se corrigio la acomulación de pagos, el calculo del saldo , los estados de las facturas , la precisión monetaria y la regla de vencimiento respecto a la fecha de corte. 
- Nivel B: Se agrego la normalización de identificaores, validación de importes y fechas, detencion de facturas y pagos duplicados y registro de incidencias por pagos fuera de corte, facturas inexistentes y clientes que no coinciden. 
- Nivel C: Se añadio validación  de cabeceras y estructura de filas, tratamiento de archivos CSV sin registros y dos pruebas propias. 

## Cómo ejecutar y verificar

Comandos utilizados y resultados observados (incluye cantidad de pruebas aprobadas/fallidas):

Comandos utilizados: 
    1. python --version
    2. python -m unittest discover -s tests -v
    3. python -m conciliador --facturas datos/ejemplo/facturas.csv --pagos datos/ejemplo/pagos.csv --corte 2026-10-15 --salida salida
    4. Get-Content salida\totales.json

resultados observados (incluye cantidad de pruebas aprobadas/fallidas):

    1. Versión de Python: 3.13.5.
    2. Pruebas automáticas: 9 aprobadas, 0 fallidas.
    3. Resultado del ejemplo: 6 facturas válidas, importe total 470.00, pagado 360.00, saldo 110.00 y 7 incidencias.
## Decisiones

Explica dos decisiones: representación del dinero y orden de validación/deduplicación.
    1. Representación del dinero
        Se utilizó decimal.Decimal en lugar de float para evitar errores de aproximación en las operaciones monetarias. Los importes se validan para admitir punto o coma decimal, con un máximo de dos decimales, y las salidas se formatean con exactamente dos decimales.

    2. Orden de validación y deduplicación
        Se procesan primero las facturas y después los pagos, conservando el orden de las filas. 
        Las facturas duplicadas se identifican después de validar la fila. 
        Para los pagos, primero se validan los datos; luego se comprueba y reserva el identificador válido antes de revisar el corte, la existencia de la factura y la coincidencia del cliente. 
        Solo los pagos que superan todas las comprobaciones se acumulan.

## Pruebas propias

Archivo: tests/test_propias.py.

    1.Factura sin pagos: comprueba que el pagado sea 0.00, el saldo coincida con el importe, el estado sea pendiente y la factura vencida se marque correctamente.

    2.Pago de cliente incorrecto: comprueba que el pago se rechace, no reduzca el saldo y genere una incidencia CLIENTE_NO_COINCIDE.

    3.Ambas pruebas se ejecutaron correctamente junto con las siete pruebas públicas.


## Uso de IA

Se utilizó IA como apoyo para resolver algunas dudas y revisar posibles mejoras. Se realizaron ajustes al código, se crearon dos pruebas propias y se verificaron los resultados ejecutando las pruebas automáticas.

## Pendientes y limitaciones

Las 9 pruebas salieron bien y los resultados del ejemplo fueron los esperados. Aún faltaria probar otros casos, como errores en las fechas, importes, encabezados y registros duplicados. También revisar qué pasa cuando los archivos están vacíos o hay errores al leerlos, y comprobar que no se generen archivos de salida si los datos de entrada tienen errores.
