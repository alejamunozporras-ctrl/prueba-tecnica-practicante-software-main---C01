"""Módulo heredado. Revisa su comportamiento con el contrato del enunciado."""
import csv
import re
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path

FACTURAS = ("factura_id", "cliente_id", "fecha_vencimiento", "importe")
PAGOS = ("pago_id", "factura_id", "cliente_id", "fecha_pago", "importe")

RESUMEN = (
    "factura_id", "cliente_id", "fecha_vencimiento",
    "importe", "pagado", "saldo", "estado", "vencida"
)
INCIDENCIAS = ("archivo", "fila", "codigo", "referencia")

CENTAVO = Decimal("0.01")
FORMATO_DINERO = re.compile(r"^[0-9]+(?:[.,][0-9]{1,2})?$")
FORMATO_FECHA = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def normalizar(valor):
    """Quita espacios exteriores y convierte el identificador a mayúsculas."""
    return (valor or "").strip().upper()


def dinero(valor):
    """Valida un importe positivo y lo representa con precisión decimal."""
    texto = (valor or "").strip()

    if not FORMATO_DINERO.fullmatch(texto):
        raise ValueError("Importe inválido")

    try:
        importe = Decimal(texto.replace(",", "."))
    except InvalidOperation as error:
        raise ValueError("Importe inválido") from error

    if not importe.is_finite() or importe <= 0:
        raise ValueError("El importe debe ser positivo")

    return importe.quantize(CENTAVO)


def fecha(valor):
    """Acepta únicamente fechas reales con formato AAAA-MM-DD."""
    texto = (valor or "").strip()

    if not FORMATO_FECHA.fullmatch(texto):
        raise ValueError("Fecha inválida")

    try:
        return date.fromisoformat(texto)
    except ValueError as error:
        raise ValueError("Fecha inválida") from error


def leer_csv(ruta, columnas):
    """Lee el CSV y valida su cabecera antes de procesar sus filas."""
    ruta = Path(ruta)

    with ruta.open(encoding="utf-8-sig", newline="") as archivo:
        lector = csv.DictReader(archivo)

        cabecera = lector.fieldnames

        if (
            cabecera is None
            or len(cabecera) != len(set(cabecera))
            or not set(columnas).issubset(cabecera)
        ):
            raise ValueError(f"Cabecera inválida: {ruta.name}")

        for fila in lector:
            # DictReader representa una línea vacía como una fila sin valores.
            if not fila or all(
                valor is None or valor == "" for valor in fila.values()
            ):
                continue

            yield lector.line_num, fila


def validar_fila(fila, columnas, campos_fecha):
    """Comprueba estructura, identificadores, fechas e importes de una fila."""
    # Una clave None indica que hay más celdas que columnas en la cabecera.
    if None in fila:
        raise ValueError("Hay celdas adicionales")

    for columna in columnas:
        if columna not in fila or fila[columna] is None:
            raise ValueError(f"Falta la columna {columna}")

    identificadores = (
        ("factura_id", "cliente_id")
        if columnas == FACTURAS
        else ("pago_id", "factura_id", "cliente_id")
    )

    valores = {}

    for campo in identificadores:
        valor = normalizar(fila[campo])
        if not valor:
            raise ValueError(f"Identificador vacío: {campo}")
        valores[campo] = valor

    for campo in campos_fecha:
        valores[campo] = fecha(fila[campo])

    valores["importe"] = dinero(fila["importe"])

    return valores


def formato_dinero(valor):
    """Devuelve una cadena monetaria con exactamente dos decimales."""
    return format(valor, ".2f")


def conciliar(facturas_path, pagos_path, fecha_corte):
    """Concilia facturas y pagos para una fecha de corte determinada."""
    corte = fecha(fecha_corte)

    facturas = {}
    pagos_vistos = set()
    incidencias = []

    # 1. Procesar primero las facturas.
    for numero, fila in leer_csv(facturas_path, FACTURAS):
        referencia = normalizar(fila.get("factura_id"))

        try:
            datos = validar_fila(
                fila,
                FACTURAS,
                ("fecha_vencimiento",)
            )
        except (ValueError, InvalidOperation, TypeError):
            incidencias.append({
                "archivo": "facturas",
                "fila": str(numero),
                "codigo": "FILA_INVALIDA",
                "referencia": referencia,
            })
            continue

        factura_id = datos["factura_id"]

        if factura_id in facturas:
            incidencias.append({
                "archivo": "facturas",
                "fila": str(numero),
                "codigo": "FACTURA_DUPLICADA",
                "referencia": factura_id,
            })
            continue

        facturas[factura_id] = {
            "cliente": datos["cliente_id"],
            "vencimiento": datos["fecha_vencimiento"],
            "importe": datos["importe"],
            "pagado": Decimal("0.00"),
        }

    # 2. Procesar los pagos en el orden original.
    for numero, fila in leer_csv(pagos_path, PAGOS):
        referencia = normalizar(fila.get("pago_id"))

        try:
            datos = validar_fila(
                fila,
                PAGOS,
                ("fecha_pago",)
            )
        except (ValueError, InvalidOperation, TypeError):
            incidencias.append({
                "archivo": "pagos",
                "fila": str(numero),
                "codigo": "FILA_INVALIDA",
                "referencia": referencia,
            })
            continue

        pago_id = datos["pago_id"]
        factura_id = datos["factura_id"]

        # El primer pago estructuralmente válido reserva su identificador.
        if pago_id in pagos_vistos:
            incidencias.append({
                "archivo": "pagos",
                "fila": str(numero),
                "codigo": "PAGO_DUPLICADO",
                "referencia": pago_id,
            })
            continue

        pagos_vistos.add(pago_id)

        if datos["fecha_pago"] > corte:
            incidencias.append({
                "archivo": "pagos",
                "fila": str(numero),
                "codigo": "PAGO_FUERA_CORTE",
                "referencia": pago_id,
            })
            continue

        if factura_id not in facturas:
            incidencias.append({
                "archivo": "pagos",
                "fila": str(numero),
                "codigo": "FACTURA_NO_EXISTE",
                "referencia": pago_id,
            })
            continue

        factura = facturas[factura_id]

        if datos["cliente_id"] != factura["cliente"]:
            incidencias.append({
                "archivo": "pagos",
                "fila": str(numero),
                "codigo": "CLIENTE_NO_COINCIDE",
                "referencia": pago_id,
            })
            continue

        factura["pagado"] += datos["importe"]

    # 3. Calcular resumen y totales con aritmética decimal exacta.
    resumen = []
    total_importe = Decimal("0.00")
    total_pagado = Decimal("0.00")

    for factura_id in sorted(facturas):
        factura = facturas[factura_id]

        importe = factura["importe"]
        pagado = factura["pagado"]
        saldo = importe - pagado

        if pagado == 0:
            estado = "PENDIENTE"
        elif saldo > 0:
            estado = "PARCIAL"
        elif saldo == 0:
            estado = "PAGADA"
        else:
            estado = "SOBREPAGADA"

        vencida = (
            "SI"
            if saldo > 0 and factura["vencimiento"] < corte
            else "NO"
        )

        resumen.append({
            "factura_id": factura_id,
            "cliente_id": factura["cliente"],
            "fecha_vencimiento": factura["vencimiento"].isoformat(),
            "importe": formato_dinero(importe),
            "pagado": formato_dinero(pagado),
            "saldo": formato_dinero(saldo),
            "estado": estado,
            "vencida": vencida,
        })

        total_importe += importe
        total_pagado += pagado

    total_saldo = total_importe - total_pagado

    return {
        "resumen": resumen,
        "incidencias": incidencias,
        "totales": {
            "facturas_validas": len(resumen),
            "importe": formato_dinero(total_importe),
            "pagado": formato_dinero(total_pagado),
            "saldo": formato_dinero(total_saldo),
            "incidencias": len(incidencias),
        },
    }