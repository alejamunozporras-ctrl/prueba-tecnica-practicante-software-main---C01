
import csv
import tempfile
import unittest
from pathlib import Path

from conciliador.engine import conciliar


class PruebasPropias(unittest.TestCase):

    def preparar_csv(self, carpeta, nombre, columnas, filas):
        ruta = Path(carpeta) / nombre

        with ruta.open("w", encoding="utf-8", newline="") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=columnas)
            escritor.writeheader()
            escritor.writerows(filas)

        return ruta

    def test_factura_sin_pagos(self):
        with tempfile.TemporaryDirectory() as temporal:
            carpeta = Path(temporal)

            facturas = self.preparar_csv(
                carpeta,
                "facturas.csv",
                ["factura_id", "cliente_id", "fecha_vencimiento", "importe"],
                [{
                    "factura_id": "F001",
                    "cliente_id": "C001",
                    "fecha_vencimiento": "2026-10-10",
                    "importe": "100.00",
                }],
            )

            pagos = self.preparar_csv(
                carpeta,
                "pagos.csv",
                ["pago_id", "factura_id", "cliente_id", "fecha_pago", "importe"],
                [],
            )

            resultado = conciliar(facturas, pagos, "2026-10-15")

            factura = resultado["resumen"][0]
            self.assertEqual(factura["pagado"], "0.00")
            self.assertEqual(factura["saldo"], "100.00")
            self.assertEqual(factura["estado"], "PENDIENTE")
            self.assertEqual(factura["vencida"], "SI")

    def test_pago_de_cliente_incorrecto(self):
        with tempfile.TemporaryDirectory() as temporal:
            carpeta = Path(temporal)

            facturas = self.preparar_csv(
                carpeta,
                "facturas.csv",
                ["factura_id", "cliente_id", "fecha_vencimiento", "importe"],
                [{
                    "factura_id": "F001",
                    "cliente_id": "C001",
                    "fecha_vencimiento": "2026-12-01",
                    "importe": "100.00",
                }],
            )

            pagos = self.preparar_csv(
                carpeta,
                "pagos.csv",
                ["pago_id", "factura_id", "cliente_id", "fecha_pago", "importe"],
                [{
                    "pago_id": "P001",
                    "factura_id": "F001",
                    "cliente_id": "C999",
                    "fecha_pago": "2026-10-10",
                    "importe": "50.00",
                }],
            )

            resultado = conciliar(facturas, pagos, "2026-10-15")

            self.assertEqual(resultado["resumen"][0]["pagado"], "0.00")
            self.assertEqual(len(resultado["incidencias"]), 1)
            self.assertEqual(
                resultado["incidencias"][0]["codigo"],
                "CLIENTE_NO_COINCIDE",
            )


if __name__ == "__main__":
    unittest.main()
